@javax.xml.bind.annotation.XmlSchema(namespace = "http://service.rs_midtest/")
package rs_midtest.client.rs_midtest.service;
