# java webservice 实例

​																						by hgwayen

## 实验目的

1.实现一个具有WebService功能的分布式对象类，能够实现求两个整数的最大值的功能。

2.在另一台计算机（虚拟机）上，编写客户端程序，通过WebService技术访问远程的基于WebService的分布式对象Max， 达到求两个整数的最大值的功能。



---



#### 一、创建并运行HelloWorldWebService.java。		

1.在`classpath`路径下新建`/rs_midtest`、`/rs_midtest/service`、`/rs_midtest/client`文件夹，在service包中编写`HelloWorldWebService.java`。例如，我的classpath为`D:\Coding\javaSave`。项目的主目录就为`D:\Coding\javaSave\rs_midtest`。

注意包名为`classpath`后的新增路径，防止无法找到主类。

```java
package rs_midtest.service;

import javax.jws.WebMethod;  
import javax.jws.WebService;  
import javax.xml.ws.Endpoint;  

@WebService  
public class HelloWorldWebService {
	
   public String EchoHelloWorld(String name){  
       System.out.println("service HelloWorld: "+name);  
       return"HelloWorld: "+name;  
   } 
   public int GetMax(int x,int y){
	    int result=0;
		result=x>y?x:y;
	    return result;
   }
	   


  @WebMethod(exclude=true)  
  public String EchoHelloWord2(String name){  
	 System.out.println("service HelloWorld2: "+name);  
     return"HelloWorld2: "+name;  
   }  
  public static void main(String[] args) {  
    
    Endpoint.publish("http://127.0.0.1:456/helloworld",new HelloWorldWebService());
    System.out.println("webservice has started.");
  }
}  
```

2.打开cmd，cd到项目位置。

![image-20211113071702809](D:\桌面\1\1.png)

通过javac编译以及java运行该程序，如图所示：

![image-20211113071756076](D:\桌面\1\2.png)

同时，在浏览器中输入`http://127.0.0.1:456/helloworld?wsdl`能够看到xml的页面，说明服务器启动成功。

![image-20211113071913770](D:\桌面\1\3.png)



#### 二、使用wsimport根据WSDL文档生成客户端访问服务器端服务所需的代码。

使用命令行cmd跳转至`rs_midtest\client`的路径下，输入如下命令： 

```bash
wsimport -s . http://127.0.0.1:456/helloworld?wsdl
```

>wsimport是jdk自带的,可以根据wsdl文档生成客户端调用代码的工具.当然,无论服务器端的WebService是用什么语言写的,都将在客户端生成Java代码.服务器端用什么写的并不重要.
>
>wsimport.exe位于JAVA_HOME\bin目录下.
>
>常用参数为:
>
>-d<目录> - 将生成.class文件。默认参数。
>
>-s<目录> - 将生成.java文件。
>
>-p<生成的新包名> -将生成的类，放于指定的包下。
>
>(wsdlurl) - http://server:port/service?wsdl，必须的参数



命令执行如图所示。

![image-20211113070607478](D:\桌面\1\4.png)

​		执行完毕后，由于使用-s会生成两份文件 .class 和 .java。复制所有的.java文件至项目地址`/rs_midtest/client`即可。同时由于之前编写的HelloWorldWebService.java文件中带有包名，因此生成的文件自动生成对应目录`./rs_midtest/service`。需要将生成文件中的包名`package rs_midtest.service;`改成`package rs_midtest.client.rs_midtest.service;`，如图所示。

![image-20211113070847118](D:\桌面\1\5.png)

切换至client路径下，通过javac编译/rs_midtest/service下的所有java文件。

![image-20211113073020359](D:\桌面\1\6.png)





#### 三、编写客户端代码MyClient.java。

1.在`/rs_midtest/client/test`中编写MyClient.java文件。仍然**注意**包名。

```java
package rs_midtest.client.test;  
import rs_midtest.client.rs_midtest.service.*;

public class MyClient {  

  public static void main(String[] args) {  
     HelloWorldWebServiceService hwss = new HelloWorldWebServiceService(); 
     HelloWorldWebService hws =hwss.getHelloWorldWebServicePort();  
                       
     String result=hws.echoHelloWorld("ecust");
     System.out.println(result);  

	 int max=hws.getMax(2,3);
	 System.out.println("max 2,3: "+max);
  }  
}
```

2.重新打开一个命令行窗口，切换到对应MyClient.java路径，编译并运行MyClient。需要开启服务器，即先运行`HelloWorldWebService.java`，再运行MyClient。

![image-20211117162619509](C:\Users\29026\AppData\Roaming\Typora\typora-user-images\image-20211117162619509.png)

![image-20211117162634670](C:\Users\29026\AppData\Roaming\Typora\typora-user-images\image-20211117162634670.png)

3.查看服务器段窗口，显示如图：

![image-20211117162710216](C:\Users\29026\AppData\Roaming\Typora\typora-user-images\image-20211117162710216.png)




#### 可能遇到的问题

1.找不到主类，由于设置了package，通过java命令运行时需要加上正确的路径。可以简单理解为classpath下对应的路径。



2.找不到某些`jar包`，这是由于jdk版本过高的原因，经过测试，jdk15上无法运行`HelloWorldWebService.java`文件，需要使用jdk8。



3.运行`MyClient.java`时报错，如图所示。

![image-20211113073657181](D:\桌面\1\9.png)

这是由于使用`wsimport`命令生成的java文件，缺少namespace导致的。需要修改对应java文件，如图，在`@XmlType(name = "EchoHelloWorld"...)`的最后添加如下代码`namespace = "http://namespace.thats.not.the.same.as.the.generated"`，注意需要用逗号将前后分隔。

![image-20211113073846859](D:\桌面\1\10.png)



