步骤：
1.先运行 HelloWorldWebService.bat
2.再运行 MyClient.bat